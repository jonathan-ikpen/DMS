<?php
require_once __DIR__ . '/../middleware/auth.php';
$user = require_auth(['student']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    flash('success', 'Document upload validation is ready. Enable file writes after configuring storage permissions.');
    redirect('student/documents.php');
}
$requirements = $pdo->query("SELECT * FROM document_requirements WHERE audience IN ('student','all') AND is_active = 1 ORDER BY name")->fetchAll();
$pageTitle = 'Documents';
$items = ['Dashboard' => 'student/dashboard.php', 'Profile' => 'student/profile.php', 'Payments' => 'student/payments.php', 'Documents' => 'student/documents.php', 'Timetable' => 'student/timetable.php', 'Announcements' => 'student/announcements.php'];
include __DIR__ . '/../components/header.php';
?>
<div class="app-layout"><?php include __DIR__ . '/../components/sidebar.php'; ?><section class="workspace"><div class="workspace-heading"><div><p class="eyebrow">Student</p><h1>Document uploads</h1></div></div><section class="feature-grid"><?php foreach ($requirements as $requirement): ?><article><h3><?= e($requirement['name']) ?></h3><p><?= e($requirement['description']) ?></p><form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="file" name="document"><button class="button button-light" type="submit">Upload</button></form></article><?php endforeach; ?></section></section></div><?php include __DIR__ . '/../components/footer.php'; ?>
