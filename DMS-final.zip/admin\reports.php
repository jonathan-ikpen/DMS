<?php
require_once __DIR__ . '/../middleware/auth.php';
require_auth(['admin']);
$reports = ['Student List', 'Staff List', 'Timetable', 'Payments', 'Expenses', 'Financial Report', 'Student Profile', 'Staff Profile'];
$pageTitle = 'Reports';
$items = ['Dashboard' => 'admin/dashboard.php', 'Students' => 'admin/users.php?role=student', 'Staff' => 'admin/users.php?role=staff', 'Courses' => 'admin/courses.php', 'Timetable' => 'admin/timetable.php', 'Payments' => 'admin/payments.php', 'Expenses' => 'admin/expenses.php', 'Reports' => 'admin/reports.php', 'Settings' => 'admin/settings.php'];
include __DIR__ . '/../components/header.php';
?>
<div class="app-layout"><?php include __DIR__ . '/../components/sidebar.php'; ?><section class="workspace"><div class="workspace-heading"><div><p class="eyebrow">Admin</p><h1>Printable reports</h1></div></div><section class="feature-grid"><?php foreach ($reports as $report): ?><article><h3><?= e($report) ?></h3><p>Ready for DomPDF export wiring from the reporting service.</p><a class="button button-light" href="<?= url('admin/reports.php') ?>">Preview</a></article><?php endforeach; ?></section></section></div><?php include __DIR__ . '/../components/footer.php'; ?>
