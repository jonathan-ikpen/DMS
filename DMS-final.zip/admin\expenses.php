<?php
require_once __DIR__ . '/../middleware/auth.php';
require_auth(['admin']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $pdo->prepare('INSERT INTO expenses (category_id, title, amount, expense_date, status, created_by) VALUES (?, ?, ?, ?, "approved", ?)')
        ->execute([(int) $_POST['category_id'], clean_string($_POST['title'] ?? ''), (float) $_POST['amount'], $_POST['expense_date'], current_user()['id']]);
    flash('success', 'Expense recorded.');
    redirect('admin/expenses.php');
}
$categories = $pdo->query('SELECT * FROM expense_categories ORDER BY name')->fetchAll();
$expenses = $pdo->query('SELECT expenses.*, expense_categories.name AS category FROM expenses INNER JOIN expense_categories ON expense_categories.id = expenses.category_id ORDER BY expense_date DESC')->fetchAll();
$pageTitle = 'Expenses';
$items = ['Dashboard' => 'admin/dashboard.php', 'Students' => 'admin/users.php?role=student', 'Staff' => 'admin/users.php?role=staff', 'Courses' => 'admin/courses.php', 'Timetable' => 'admin/timetable.php', 'Payments' => 'admin/payments.php', 'Expenses' => 'admin/expenses.php', 'Reports' => 'admin/reports.php', 'Settings' => 'admin/settings.php'];
include __DIR__ . '/../components/header.php';
?>
<div class="app-layout"><?php include __DIR__ . '/../components/sidebar.php'; ?><section class="workspace"><div class="workspace-heading"><div><p class="eyebrow">Admin</p><h1>Expenses</h1></div></div><form class="panel form-grid" method="post"><?= csrf_field() ?><label>Category <select name="category_id"><?php foreach ($categories as $category): ?><option value="<?= e((string) $category['id']) ?>"><?= e($category['name']) ?></option><?php endforeach; ?></select></label><label>Title <input name="title" required></label><label>Amount <input type="number" step="0.01" name="amount" required></label><label>Date <input type="date" name="expense_date" required></label><button class="button button-dark" type="submit">Record expense</button></form><section class="panel table-panel"><table><thead><tr><th>Title</th><th>Category</th><th>Amount</th><th>Date</th><th>Status</th></tr></thead><tbody><?php foreach ($expenses as $expense): ?><tr><td><?= e($expense['title']) ?></td><td><?= e($expense['category']) ?></td><td><?= e(money($expense['amount'])) ?></td><td><?= e($expense['expense_date']) ?></td><td><?= e($expense['status']) ?></td></tr><?php endforeach; ?></tbody></table></section></section></div><?php include __DIR__ . '/../components/footer.php'; ?>
