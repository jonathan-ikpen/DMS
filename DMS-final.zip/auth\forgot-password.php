<?php
require_once __DIR__ . '/../config/app.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    flash('success', 'If the email exists, a reset instruction has been recorded for the administrator.');
    redirect('auth/login.php');
}
$pageTitle = 'Forgot Password';
include __DIR__ . '/../components/header.php';
?>
<section class="auth-shell">
    <form class="auth-card" method="post">
        <?= csrf_field() ?>
        <p class="eyebrow">Account recovery</p>
        <h1>Reset password</h1>
        <label>Email <input type="email" name="email" required></label>
        <button class="button button-dark" type="submit">Request reset</button>
    </form>
</section>
<?php include __DIR__ . '/../components/footer.php'; ?>
