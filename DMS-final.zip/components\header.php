<?php
$pageTitle = $pageTitle ?? APP_NAME;
$bodyClass = $bodyClass ?? '';
$user = function_exists('current_user') ? current_user() : null;
?>
<!doctype html>
<html lang="en" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= url('assets/css/app.css') ?>">
    <script defer src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script defer src="<?= url('assets/js/app.js') ?>"></script>
</head>
<body class="<?= e($bodyClass) ?>">
<header class="topbar">
    <a class="brand" href="<?= url('index.php') ?>" aria-label="Department Management System home">
        <span class="brand-mark">D</span>
        <span>DMS</span>
    </a>
    <nav class="nav">
        <a href="<?= url('index.php#features') ?>">Features</a>
        <a href="<?= url('announcements.php') ?>">Announcements</a>
        <a href="<?= url('contact.php') ?>">Contact</a>
        <?php if ($user): ?>
            <a href="<?= url($user['role'] . '/dashboard.php') ?>">Dashboard</a>
            <a class="button button-ghost" href="<?= url('auth/logout.php') ?>">Logout</a>
        <?php else: ?>
            <a href="<?= url('auth/login.php') ?>">Login</a>
            <a class="button button-dark" href="<?= url('auth/register.php') ?>">Register</a>
        <?php endif; ?>
        <button class="icon-button" type="button" data-theme-toggle aria-label="Toggle theme">◐</button>
    </nav>
</header>
<main>
<?php foreach (flash_messages() as $type => $messages): ?>
    <?php foreach ($messages as $message): ?>
        <div class="flash flash-<?= e($type) ?>"><?= e($message) ?></div>
    <?php endforeach; ?>
<?php endforeach; ?>
