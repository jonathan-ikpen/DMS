<?php
require_once __DIR__ . '/../middleware/auth.php';
require_auth(['admin']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $pdo->prepare('INSERT INTO timetable (course_id, staff_id, day_of_week, start_time, end_time, venue, level, semester) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([(int) $_POST['course_id'], (int) $_POST['staff_id'], clean_string($_POST['day_of_week'] ?? ''), $_POST['start_time'], $_POST['end_time'], clean_string($_POST['venue'] ?? ''), clean_string($_POST['level'] ?? ''), clean_string($_POST['semester'] ?? '')]);
    flash('success', 'Timetable slot added.');
    redirect('admin/timetable.php');
}
$courses = $pdo->query('SELECT id, code, title FROM courses ORDER BY code')->fetchAll();
$staff = $pdo->query('SELECT staff.id, users.name FROM staff INNER JOIN users ON users.id = staff.user_id ORDER BY users.name')->fetchAll();
$slots = $pdo->query('SELECT timetable.*, courses.code, users.name AS lecturer FROM timetable INNER JOIN courses ON courses.id = timetable.course_id LEFT JOIN staff ON staff.id = timetable.staff_id LEFT JOIN users ON users.id = staff.user_id ORDER BY day_of_week, start_time')->fetchAll();
$pageTitle = 'Timetable';
$items = ['Dashboard' => 'admin/dashboard.php', 'Students' => 'admin/users.php?role=student', 'Staff' => 'admin/users.php?role=staff', 'Courses' => 'admin/courses.php', 'Timetable' => 'admin/timetable.php', 'Payments' => 'admin/payments.php', 'Expenses' => 'admin/expenses.php', 'Reports' => 'admin/reports.php', 'Settings' => 'admin/settings.php'];
include __DIR__ . '/../components/header.php';
?>
<div class="app-layout"><?php include __DIR__ . '/../components/sidebar.php'; ?><section class="workspace">
<div class="workspace-heading"><div><p class="eyebrow">Admin</p><h1>Timetable builder</h1></div></div>
<form class="panel form-grid" method="post"><?= csrf_field() ?><label>Course <select name="course_id"><?php foreach ($courses as $course): ?><option value="<?= e((string) $course['id']) ?>"><?= e($course['code']) ?> - <?= e($course['title']) ?></option><?php endforeach; ?></select></label><label>Lecturer <select name="staff_id"><?php foreach ($staff as $row): ?><option value="<?= e((string) $row['id']) ?>"><?= e($row['name']) ?></option><?php endforeach; ?></select></label><label>Day <select name="day_of_week"><option>Monday</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option></select></label><label>Start <input type="time" name="start_time" required></label><label>End <input type="time" name="end_time" required></label><label>Venue <input name="venue" required></label><label>Level <select name="level"><option>ND1</option><option>ND2</option><option>HND1</option><option>HND2</option></select></label><label>Semester <select name="semester"><option>First</option><option>Second</option></select></label><button class="button button-dark" type="submit">Add slot</button></form>
<section class="panel timetable-board"><?php foreach ($slots as $slot): ?><article draggable="true"><strong><?= e($slot['code']) ?></strong><span><?= e($slot['day_of_week']) ?> <?= e(substr($slot['start_time'], 0, 5)) ?> - <?= e(substr($slot['end_time'], 0, 5)) ?></span><small><?= e($slot['lecturer'] ?? 'Unassigned') ?> · <?= e($slot['venue']) ?></small></article><?php endforeach; ?></section>
</section></div><?php include __DIR__ . '/../components/footer.php'; ?>
