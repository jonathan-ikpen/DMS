<?php
declare(strict_types=1);

function base_path(string $path = ''): string
{
    return dirname(__DIR__) . ($path ? DIRECTORY_SEPARATOR . ltrim($path, DIRECTORY_SEPARATOR) : '');
}

function url(string $path = ''): string
{
    return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
}

function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function active_link(string $needle): string
{
    $current = $_SERVER['REQUEST_URI'] ?? '';
    return str_contains($current, $needle) ? 'is-active' : '';
}

function money(float|int|string|null $amount): string
{
    return 'NGN ' . number_format((float) $amount, 2);
}

function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name));
    $letters = array_map(fn ($part) => strtoupper(substr($part, 0, 1)), array_slice($parts ?: ['D'], 0, 2));
    return implode('', $letters);
}
