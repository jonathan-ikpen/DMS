</main>
<footer class="footer">
    <p>&copy; <?= date('Y') ?> Department Management System. Built for accurate records, scheduling, and financial accountability.</p>
</footer>
</body>
</html>
