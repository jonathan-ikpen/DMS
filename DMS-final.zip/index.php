<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Home';
include __DIR__ . '/components/header.php';
?>
<section class="hero">
    <div class="hero-copy">
        <p class="eyebrow">Computer Science Department</p>
        <h1>Department Management System</h1>
        <p>One calm workspace for student records, staff profiles, payments, schedules, expenses, announcements, and reports.</p>
        <div class="hero-actions">
            <a class="button button-dark" href="<?= url('auth/register.php') ?>">Create account</a>
            <a class="button button-light" href="<?= url('auth/login.php') ?>">Sign in</a>
        </div>
    </div>
    <div class="hero-panel" aria-label="DMS overview">
        <div class="metric-row"><span>Paid students</span><strong>Verified</strong></div>
        <div class="metric-row"><span>Timetable</span><strong>Live</strong></div>
        <div class="metric-row"><span>Expenses</span><strong>Auditable</strong></div>
        <div class="metric-row"><span>Documents</span><strong>Validated</strong></div>
    </div>
</section>
<section class="section" id="features">
    <div class="section-heading">
        <p class="eyebrow">Modules</p>
        <h2>Designed around departmental work.</h2>
    </div>
    <div class="feature-grid">
        <article><h3>Student records</h3><p>Registration, biodata, payments, receipts, timetable access, notifications, and document uploads.</p></article>
        <article><h3>Staff operations</h3><p>Staff profiles, passports, CVs, qualifications, assigned courses, and schedule visibility.</p></article>
        <article><h3>Admin control</h3><p>User activation, courses, timetable builder, expenses, reports, announcements, audit logs, and settings.</p></article>
        <article><h3>Financial clarity</h3><p>Payment history, expense categories, custom categories, automatic balance summaries, and printable reports.</p></article>
    </div>
</section>
<section class="section split">
    <div>
        <p class="eyebrow">Security</p>
        <h2>Role-based access with defensive defaults.</h2>
    </div>
    <ul class="check-list">
        <li>PDO prepared statements and password hashing</li>
        <li>CSRF tokens, session timeout, and XSS escaping</li>
        <li>File validation for uploads and document requirements</li>
        <li>Audit logs for administrative actions</li>
    </ul>
</section>
<?php include __DIR__ . '/components/footer.php'; ?>
