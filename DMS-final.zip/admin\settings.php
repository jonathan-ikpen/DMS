<?php
require_once __DIR__ . '/../middleware/auth.php';
require_auth(['admin']);
$pageTitle = 'Settings';
$items = ['Dashboard' => 'admin/dashboard.php', 'Students' => 'admin/users.php?role=student', 'Staff' => 'admin/users.php?role=staff', 'Courses' => 'admin/courses.php', 'Timetable' => 'admin/timetable.php', 'Payments' => 'admin/payments.php', 'Expenses' => 'admin/expenses.php', 'Reports' => 'admin/reports.php', 'Settings' => 'admin/settings.php'];
include __DIR__ . '/../components/header.php';
?>
<div class="app-layout"><?php include __DIR__ . '/../components/sidebar.php'; ?><section class="workspace"><div class="workspace-heading"><div><p class="eyebrow">Admin</p><h1>Settings</h1></div></div><section class="panel"><h2>Document requirements</h2><p>Configure required student and staff uploads in the database table <strong>document_requirements</strong>.</p></section><section class="panel"><h2>Remita</h2><p>Add merchant credentials in <strong>settings</strong> before enabling live payments.</p></section></section></div><?php include __DIR__ . '/../components/footer.php'; ?>
