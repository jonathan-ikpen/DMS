<?php
require_once __DIR__ . '/../middleware/auth.php';
require_auth(['admin']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $pdo->prepare('INSERT INTO courses (code, title, credit_units, level, semester, status) VALUES (?, ?, ?, ?, ?, "active")')
        ->execute([clean_string($_POST['code'] ?? ''), clean_string($_POST['title'] ?? ''), (int) $_POST['credit_units'], clean_string($_POST['level'] ?? ''), clean_string($_POST['semester'] ?? '')]);
    flash('success', 'Course added.');
    redirect('admin/courses.php');
}
$courses = $pdo->query('SELECT * FROM courses ORDER BY level, code')->fetchAll();
$pageTitle = 'Courses';
$items = ['Dashboard' => 'admin/dashboard.php', 'Students' => 'admin/users.php?role=student', 'Staff' => 'admin/users.php?role=staff', 'Courses' => 'admin/courses.php', 'Timetable' => 'admin/timetable.php', 'Payments' => 'admin/payments.php', 'Expenses' => 'admin/expenses.php', 'Reports' => 'admin/reports.php', 'Settings' => 'admin/settings.php'];
include __DIR__ . '/../components/header.php';
?>
<div class="app-layout"><?php include __DIR__ . '/../components/sidebar.php'; ?><section class="workspace">
<div class="workspace-heading"><div><p class="eyebrow">Admin</p><h1>Course management</h1></div></div>
<form class="panel form-grid" method="post"><?= csrf_field() ?><label>Code <input name="code" required></label><label>Title <input name="title" required></label><label>Units <input type="number" name="credit_units" min="1" value="3"></label><label>Level <select name="level"><option>ND1</option><option>ND2</option><option>HND1</option><option>HND2</option></select></label><label>Semester <select name="semester"><option>First</option><option>Second</option></select></label><button class="button button-dark" type="submit">Add course</button></form>
<section class="panel table-panel"><table><thead><tr><th>Code</th><th>Title</th><th>Units</th><th>Level</th><th>Semester</th></tr></thead><tbody><?php foreach ($courses as $course): ?><tr><td><?= e($course['code']) ?></td><td><?= e($course['title']) ?></td><td><?= e((string) $course['credit_units']) ?></td><td><?= e($course['level']) ?></td><td><?= e($course['semester']) ?></td></tr><?php endforeach; ?></tbody></table></section>
</section></div><?php include __DIR__ . '/../components/footer.php'; ?>
