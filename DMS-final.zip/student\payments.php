<?php
require_once __DIR__ . '/../middleware/auth.php';
$user = require_auth(['student']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $reference = 'RMT-' . strtoupper(bin2hex(random_bytes(5)));
    $pdo->prepare('INSERT INTO payments (user_id, gateway, reference, amount, status, paid_at) VALUES (?, "Remita", ?, ?, "pending", NULL)')
        ->execute([$user['id'], $reference, (float) $_POST['amount']]);
    flash('success', 'Payment reference generated. Verify after payment confirmation.');
    redirect('student/payments.php');
}
$statement = $pdo->prepare('SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC');
$statement->execute([$user['id']]);
$payments = $statement->fetchAll();
$pageTitle = 'Payments';
$items = ['Dashboard' => 'student/dashboard.php', 'Profile' => 'student/profile.php', 'Payments' => 'student/payments.php', 'Documents' => 'student/documents.php', 'Timetable' => 'student/timetable.php', 'Announcements' => 'student/announcements.php'];
include __DIR__ . '/../components/header.php';
?>
<div class="app-layout"><?php include __DIR__ . '/../components/sidebar.php'; ?><section class="workspace"><div class="workspace-heading"><div><p class="eyebrow">Student</p><h1>Remita payments</h1></div></div><form class="panel form-grid" method="post"><?= csrf_field() ?><label>Amount <input type="number" step="0.01" name="amount" value="15000" required></label><button class="button button-dark" type="submit">Generate reference</button></form><section class="panel table-panel"><table><thead><tr><th>Reference</th><th>Gateway</th><th>Amount</th><th>Status</th><th>Receipt</th></tr></thead><tbody><?php foreach ($payments as $payment): ?><tr><td><?= e($payment['reference']) ?></td><td><?= e($payment['gateway']) ?></td><td><?= e(money($payment['amount'])) ?></td><td><?= e($payment['status']) ?></td><td><a href="<?= url('student/payments.php') ?>">Download</a></td></tr><?php endforeach; ?></tbody></table></section></section></div><?php include __DIR__ . '/../components/footer.php'; ?>
